<?php
class Home_model extends CI_Model {

        public function login(){
                
        }
}