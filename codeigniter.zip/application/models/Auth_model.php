<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

    public function register_user($data) {
        $this->db->insert('usuarios', $data);
    }

    public function login_user($email, $password) {
        $this->db->where('correo', $email);
        $this->db->where('contrasena', $password);
        $query = $this->db->get('usuarios');

        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
}
