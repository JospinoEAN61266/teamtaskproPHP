<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('auth_model');
    }

    public function index() {
        $this->load->view('user/login');
    }

    public function principal() {
        $this->load->view('user/principal');
    }

    public function do_register() {
        $data = array(
            'correo' => $this->input->post('email'),
            'contrasena' => $this->input->post('password')
        );

        $this->auth_model->register_user($data);
        // Puedes redirigir a la página de inicio de sesión o mostrar un mensaje de éxito.
    }

    public function do_login() {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
		$resp = $this->auth_model->login_user($email, $password);

        if ($resp) {
        	$data = [
				"id" => $resp->id,
				"name" => $resp->correo,
				"login" => TRUE
			];
			$this->session->set_userdata($data);
    	} else {
        	echo "error";
    	}
    }
}
