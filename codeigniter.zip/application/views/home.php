<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeamTaskPro - Gestor de Tareas para Equipos Remotos</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark px-5">
            <div class="container-fluid">
                <button class="navbar-toggler m-3" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <a class="navbar-brand fs-3 fw-bold" href="#aplication-form">TeamTaskPro</a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#Home">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#Register">Registro</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#Statistics" tabindex="-1">Estadísticas</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-primary px-4 rounded-pill ms-3" href="#" id="sign-in-link">Iniciar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <section id="Home" class="py-3">
        <div class="container my-5">
            <div
                class="row pb-0 pe-lg-0 pt-lg-5 align-items-center justify-content-center rounded-3 border shadow-lg">
                <div class="col-lg-6 p-3 p-lg-5 pt-lg-3">
                    <h1 class="display-4 fw-bold lh-1">Gestiona Tareas para Equipos Remotos</h1>
                    <p class="lead">Simplifica la gestión de tareas para equipos remotos con TeamTaskPro. Nuestra plataforma
                        te permite organizar, asignar y hacer un seguimiento de las tareas de tu equipo de manera eficiente.
                        Desde la colaboración en proyectos hasta la supervisión del progreso, hacemos que trabajar
                        remotamente sea más productivo y colaborativo. Deja de preocuparte por la distancia y comienza a
                        trabajar de manera más inteligente y efectiva.</p>
                </div>
                <div class="col-sm-8 col-lg-5 offset-lg-1 p-0 overflow-hidden shadow-lg my-3">
                    <img class="rounded-lg-3 img-fluid rounded-3" src="assets/images/Successful-Job-Interview.jpg" alt=""
                        width="720">
                </div>
            </div>
        </div>
    </section>

    <section id="Register">
        <div class="container col-xl-10 col-xxl-8 px-4 py-5">
            <div class="row align-items-center g-lg-5 py-5">
                <div class="col-lg-7 text-center text-lg-start">
                    <h1 class="display-4 fw-bold lh-1 mb-3">Únete a TeamTaskPro, Gestiona Tareas como Nunca Antes</h1>
                    <p class="lead col-lg-10 fs-4">Haz parte de nuestra plataforma y lleva la gestión de tareas para equipos
                        remotos al siguiente nivel. Regístrate y descubre cómo TeamTaskPro puede optimizar la
                        colaboración y la productividad de tu equipo, independientemente de su ubicación.</p>
                </div>
                <div class="col-sm-11 mx-auto col-lg-5">
                    <form class="p-4 p-md-5 border rounded-3 bg-light" id="registrationForm" action="<?php echo base_url('user/do_register'); ?>" method="POST">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" name="email" placeholder="name@example.com"
                                autofocus="autofocus" required>
                            <label for="floatingInput">Correo Electrónico</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password"
                                required>
                            <label for="floatingPassword">Contraseña</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="floatingPasswordConfirmation" placeholder="Password" required>
                            <label for="floatingPasswordConfirmation">Confirmar Contraseña</label>
                        </div>
                        <button class="w-100 btn btn-lg btn-primary" type="submit">Regístrate</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="registrationModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body d-flex flex-column align-items-center justify-content-center py-4">
                        <i class="bi bi-check-circle custom-success-font custom-icon"></i>
                        <p class="text-center fs-3 fw-bolder m-0 ms-3">Tu registro ha sido exitoso</p>
                    </div>
                    <div class="modal-footer p-0">
                        <button type="button" class="btn btn-primary w-100 m-0 rounded-0 btn-lg py-2 fs-4"
                            data-bs-dismiss="modal">Confirmar</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="Statistics">
        <div class="px-4 mb-2 text-center">
            <h1 class="display-4 fw-bold">Optimiza la Colaboración Remota</h1>
            <div class="col-lg-6 mx-auto mb-5">
                <p class="lead mb-4">Construye la colaboración efectiva en tu equipo remoto con TeamTaskPro. Ofrecemos un
                    entorno diseñado para empoderar a tu equipo y proporcionar las herramientas necesarias para alcanzar
                    metas profesionales. Sé nuestro socio en cada paso del camino, proporcionándote acceso a un sistema
                    de gestión de tareas que permita el crecimiento y la prosperidad en tu equipo.</p>
            </div>
            <div>
                <div class="container px-0 px-sm-5">
                    <table class="table shadow p-3 mb-5 bg-body rounded" id="statsTable">
                        <thead>
                            <tr>
                                <th scope="col">Estadística</th>
                                <th scope="col">Cifra</th>
                                <th scope="col">Descripción</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top px-5">
            <div class="col-md-4 d-flex align-items-center">
                <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
                    <svg class="bi" width="30" height="24">
                        <use xlink:href="#bootstrap" />
                    </svg>
                </a>
                <span class="mb-3 mb-md-0 text-muted">&copy; 2023 TeamTaskPro - Gestor de Tareas para Equipos Remotos</span>
            </div>

            <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
                <li class="ms-3"><a class="text-muted" href="https://twitter.com/" target="_blank"><i
                            class="bi bi-twitter"></i></a></li>
                <li class="ms-3"><a class="text-muted" href="https://www.instagram.com/" target="_blank"><i
                            class="bi bi-instagram"></i></a></li>
                <li class="ms-3"><a class="text-muted" href="https://www.facebook.com/" target="_blank"><i
                            class="bi bi-facebook"></i></a></li>
            </ul>
        </footer>
    </div>

    <script src="assets/js/mylib.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#sign-in-link').click(function(e) {
                window.location.href = "user"; // Cambiado a "user" en lugar de "home" para el ejemplo
            });
        });

        $(document).ready(function () {
            $("#registrationForm").submit(function (e) {
                e.preventDefault();
                var form = $(this);
                $.ajax({
                    url: form.attr("action"),
                    type: form.attr("method"),
                    data: form.serialize(),
                    success: function (resp) {
                        console.log("registro exitoso");
                        window.location.href = "user"
                    },
                });
            });
        });
    </script>
</body>

</html>
