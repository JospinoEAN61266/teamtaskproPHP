<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeamTaskPro</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            font-family: 'Lato', sans-serif;
            line-height: 1.6;
        }
        @media (min-width: 768px) {
            .gradient-form {
                height: 100vh !important;
            }
        }
        @media (min-width: 769px) {
            .gradient-custom-2 {
                border-top-right-radius: .3rem;
                border-bottom-right-radius: .3rem;
            }
        }
    </style>
</head>

<body>
<section class="h-100 vh-100" style="background-color: #eee;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-10">
        <div class="card rounded-3 text-black">
          <div class="row g-0">
            <div class="col-lg-6">
              <div class="card-body p-md-5 mx-md-4">

                <div class="text-center">
                  <h4 class="mt-1 mb-5 pb-1">Bienvenido a TeamTaskPro</h4>
                </div>

                <form id="loginForm" action="<?php echo base_url('user/do_login'); ?>" method="POST">
                  <p>Por favor inicia sesión para gestionar tareas y colaborar con tu equipo.</p>

                  <div class="form-outline mb-4">
                    <input type="email" name="email" class="form-control"
                      placeholder="Correo electrónico" />
                    <label class="form-label" for="form2Example11">Usuario</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" name="password" class="form-control" />
                    <label class="form-label" for="form2Example22">Contraseña</label>
                  </div>

                  <div class="text-center pt-1 mb-5 pb-1">
                    <button class="btn btn-primary btn-block fa-lg mb-3" type="submit">Iniciar sesión</button>
                  </div>

                  <div class="d-flex align-items-center justify-content-center pb-4">
                    <p class="mb-0 me-2">¿No tienes una cuenta?</p>
                    <button type="button" class="btn btn-outline-primary" id="register-button">Regístrate ya</button>
                  </div>

                </form>
              </div>
            </div>
            <div class="col-lg-6 d-flex align-items-center bg-primary">
              <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                <h4 class="mb-4">Haz que la colaboración sea eficiente</h4>
                <p class="small mb-0">Gestiona tareas, colabora con tu equipo y haz que cada proyecto sea un éxito. TeamTaskPro te ofrece las herramientas que necesitas para trabajar de manera eficiente y coordinada.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#loginForm').submit(function(e) {
            e.preventDefault();
            var form = $(this);
            $.ajax({
                url: form.attr('action'),
                type: form.attr('method'),
                data: form.serialize(),
                success: function(resp) {
                    if (resp==="error") {
                        alert('Los datos no existen dentro de la base de datos')
                    } else {
                        window.location.href = "user/principal"
                    }
                },
                error: function(error) {
                    alert("Usuario o contraseña incorrectos")
                }
            });
        });
    });

    $(document).ready(function() {
        $('#register-button').click(function(e) {
            window.location.href = "home"
        });
    });
</script>
</body>
</html>