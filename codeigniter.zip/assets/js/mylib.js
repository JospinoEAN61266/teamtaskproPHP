const registrationForm = document.getElementById("registrationForm");

const termsConditions = `<div class="tcContainer container bg-body-secondary fs-6">
    <p>
        Bienvenido a TeamTaskPro, tu plataforma dedicada a la gestión eficiente de tareas para equipos remotos. Antes de utilizar nuestros servicios, te pedimos que leas detenidamente estos Términos y Condiciones de Registro. Al registrarte en nuestra plataforma, aceptas cumplir con los siguientes términos y condiciones. Si no estás de acuerdo con alguna parte de estos términos, por favor, abstente de registrarte y utilizar nuestros servicios.
    </p>
    <ol>
        <li>
            <strong>Registro y Cuenta:</strong>
            <ol type="a">
                <li>Para registrarte en TeamTaskPro, debes proporcionar información precisa y actualizada.</li>
                <li>Eres responsable de mantener la confidencialidad de tu cuenta y contraseña.</li>
                <li>Nos reservamos el derecho de suspender o cancelar tu cuenta en caso de detectar información falsa o actividades que violen estos términos.</li>
            </ol>
        </li>
        <li>
            <strong>Uso del Servicio:</strong>
            <ol type="a">
                <li>Te comprometes a utilizar nuestros servicios de manera ética y legal.</li>
                <li>No puedes utilizar TeamTaskPro con fines ilegales o no autorizados.</li>
                <li>Nos reservamos el derecho de modificar o discontinuar el servicio en cualquier momento sin previo aviso.</li>
            </ol>
        </li>
        <li>
            <strong>Contenido del Usuario:</strong>
            <ol type="a">
                <li>Al registrarte, aceptas que el contenido que compartas en TeamTaskPro, como tareas y comentarios, sea visible para otros usuarios del equipo.</li>
                <li>Te comprometes a no publicar contenido ofensivo, difamatorio, o que viole los derechos de propiedad intelectual de terceros.</li>
            </ol>
        </li>
        <li>
            <strong>Privacidad:</strong>
            <ol type="a">
                <li>Tu privacidad es importante para nosotros. Consulta nuestra Política de Privacidad para comprender cómo recopilamos, usamos y protegemos tu información personal.</li>
            </ol>
        </li>
        <li>
            <strong>Responsabilidades del Usuario:</strong>
            <ol type="a">
                <li>Eres responsable de cualquier actividad que ocurra bajo tu cuenta.</li>
                <li>Aceptas notificarnos inmediatamente sobre cualquier uso no autorizado de tu cuenta o cualquier otra violación de seguridad.</li>
            </ol>
        </li>
        <li>
            <strong>Modificaciones a los Términos:</strong>
            <ol type="a">
                <li>Nos reservamos el derecho de modificar estos Términos y Condiciones en cualquier momento. Las modificaciones entrarán en vigencia inmediatamente después de su publicación.</li>
            </ol>
        </li>
        <li>
            <strong>Finalización del Servicio:</strong>
            <ol type="a">
                <li>Nos reservamos el derecho de suspender o dar por terminado tu acceso al servicio en cualquier momento, por cualquier motivo, sin previo aviso.</li>
            </ol>
        </li>
        <li>
            <strong>Ley Aplicable:</strong>
            <ol type="a">
                <li>Estos Términos y Condiciones se rigen por las leyes de tu jurisdicción, y cualquier disputa estará sujeta a la jurisdicción de los tribunales competentes de tu área.</li>
            </ol>
        </li>
    </ol>
    <p>
        Al registrarte en TeamTaskPro, aceptas estos Términos y Condiciones. Te instamos a revisar esta página regularmente para estar al tanto de cualquier cambio. Si tienes alguna pregunta o inquietud, por favor, contáctanos.
        Fecha de entrada en vigencia: [Fecha actual]
        Gracias por ser parte de la comunidad de TeamTaskPro
    </p>
</div>`;


document.querySelectorAll("nav a").forEach((anchor) => {
	anchor.addEventListener("click", function (e) {
		e.preventDefault();
		document.querySelector(this.getAttribute("href")).scrollIntoView({
			behavior: "smooth",
		});
	});
	console.log(anchor);
});

registrationForm.addEventListener("submit", function (event) {
	event.preventDefault();
	if (validateForm()) {
		(async () => {
			const { value: accept } = await Swal.fire({
				title: "Términos y condiciones",
				html: termsConditions,
				input: "checkbox",
				inputValue: 1,
				inputPlaceholder: `Estoy de acuerdo con los términos y condiciones`,
				confirmButtonText: `Continue&nbsp;<i class="fa fa-arrow-right"></i>`,
				inputValidator: (result) => {
					return (
						!result && "Debes aceptar los T&C para continuar con el registro"
					);
				},
			});
			if (accept) {
				Swal.fire({
					icon: "success",
					title: "Registro exitoso",
					text: "¡Tu registro ha sido exitoso!",
					confirmButtonText: "OK",
				});
				registrationForm.reset();
			}
		})();
	}
});

function validateForm() {
	var password = document.getElementById("floatingPassword").value;
	var confirmPassword = document.getElementById(
		"floatingPasswordConfirmation"
	).value;
	if (password !== confirmPassword) {
		Swal.fire({
			icon: "error",
			title: "Oops...",
			text: "Las contraseñas no coinciden.",
		});
		return false;
	}
	return true;
}

const statsDataList = [
	{
		name: "Proyectos Activos",
		amount: "Más de 1,000",
		description:
			"Proyectos en curso, gestionados de manera eficiente por nuestros usuarios.",
	},
	{
		name: "Tareas Completadas",
		amount: "Más de 500,000",
		description:
			"Miles de tareas han sido completadas con éxito utilizando TeamTaskPro.",
	},
	{
		name: "Equipos Registrados",
		amount: "Más de 10,000",
		description:
			"Más de 10,000 equipos confían en TeamTaskPro para una gestión efectiva de tareas.",
	},
];

const statsTable = document.getElementById("statsTable");
const tbody = statsTable.getElementsByTagName("tbody")[0];

statsDataList.forEach((statObj) => {
	const row = tbody.insertRow();
	const cell1 = row.insertCell(0);
	const cell2 = row.insertCell(1);
	const cell3 = row.insertCell(2);

	cell1.textContent = statObj.name;
	cell2.textContent = statObj.amount;
	cell3.textContent = statObj.description;
});
